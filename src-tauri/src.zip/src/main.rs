#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod injector;
mod theme_manager;
mod backup;
mod marketplace;
mod sandbox;

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            injector::find_discord,
            injector::inject_loader,
            injector::uninject_loader,
            injector::is_injected,
            theme_manager::list_themes,
            theme_manager::activate_theme,
            theme_manager::delete_theme,
            theme_manager::import_theme_from_path,
            backup::create_backup,
            backup::list_backups,
            backup::restore_backup,
            marketplace::fetch_registry,
            marketplace::download_theme_from_url,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
