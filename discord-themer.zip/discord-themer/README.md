# DiscordThemer v4 — Plugin & Theme Guide

## File locations

All files go in `%APPDATA%\DiscordThemer\`

```
%APPDATA%\DiscordThemer\
  state.json              ← auto-generated, tracks active theme + enabled plugins
  custom.css              ← your custom CSS (edited in the settings panel)
  themes\
    midnight-purple\      ← folder theme
      theme.json          ← metadata
      theme.css           ← main styles
      animations.js       ← JS animations (optional)
      extra.css           ← extra CSS files (all .css files are loaded)
    SomeTheme.css         ← BetterDiscord single-file theme (also works!)
  plugins\
    snowflakes\           ← plugin folder
      plugin.json         ← metadata
      index.js            ← main plugin code
      helper.js           ← extra JS (all .js files are loaded)
      style.css           ← plugin CSS (optional)
```

---

## Theme format

### Folder theme (recommended)
`theme.json`:
```json
{
  "name": "My Theme",
  "author": "You",
  "version": "1.0.0",
  "description": "A cool theme"
}
```
- All `.css` files in the folder are loaded
- All `.js` files in the folder are executed in the renderer
- No `css_file` needed — it loads everything

### BetterDiscord format (single .css file)
Just drop any `.css` file directly in the `themes\` folder.
Supports BD META comments:
```css
/**
 * @name My Theme
 * @author Author
 * @version 1.0.0
 * @description A theme
 */
```

---

## Plugin format

`plugin.json`:
```json
{
  "name": "My Plugin",
  "author": "You",
  "version": "1.0.0",
  "description": "Does cool stuff"
}
```

`index.js` — runs in Discord's renderer, has DOM access:
```js
// Wrap in IIFE to avoid global pollution
(function() {
  if (window.__myPlugin) return;
  window.__myPlugin = true;

  // Do stuff
  console.log("Plugin loaded!");

  // CSS via style tag
  var style = document.createElement("style");
  style.textContent = `.someClass { color: red !important; }`;
  document.head.appendChild(style);

  // Expose a stop function (good practice)
  window.__myPlugin_stop = function() {
    style.remove();
    window.__myPlugin = false;
  };
})();
```

**What plugins CAN do:**
- Full DOM manipulation
- Inject CSS / style tags
- Canvas animations, particle effects
- MutationObserver hooks
- fetch() API calls
- Intercept Discord's webpack modules via `webpackChunkdiscord_app`

**What plugins CANNOT do:**
- `require()` Node.js modules (renderer sandbox)
- Access the filesystem directly
- Use `ipcRenderer` unless Discord exposes it

---

## Accessing settings

Two ways to open DiscordThemer settings:
1. Click `🎨 Themer` button in the top bar → opens Discord settings to your panel
2. Open Discord settings manually (gear icon) → scroll down to **DiscordThemer** section in the sidebar

---

## Example plugins to build

- **Custom cursor** — replace Discord's cursor with a custom one
- **Message animations** — animate new messages sliding in
- **Particle effects** — mouse trail particles
- **Status globe** — animated globe next to your username
- **Chat bubbles** — style messages as chat bubbles
- **Nitro fake** — cosmetic only badge display tweaks
- **Always on top** — IPC bridge to set Discord window always-on-top
